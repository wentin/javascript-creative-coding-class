# About Project Template
The project template is your starting point of projects for Javascript Creative Coding class. 

### How to use
* You need to have `grunt cli` tool first. If you already have it, skip this step
```
$ npm install -g grunt-cli 
```
* You need `grunt` installed:
```
$ npm install
```
* Run grunt
```
$ grunt
```
* Go [`http://localhost:8080`](http://localhost:8080) in the browser

